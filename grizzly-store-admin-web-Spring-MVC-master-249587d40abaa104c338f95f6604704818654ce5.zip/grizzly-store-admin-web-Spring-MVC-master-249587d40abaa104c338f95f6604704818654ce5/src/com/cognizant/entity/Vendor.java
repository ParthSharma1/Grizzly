package com.cognizant.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vendorlogin")
public class Vendor {
	@Id
	@Column(name="userName")
	private String vendorName;
	@Column(name="VendorId")
	private String VendorId;
	
	
	public String getVendorId() {
		return VendorId;
	}
	public void setVendorId(String vendorId) {
		VendorId = vendorId;
	}
	@Column(name="passWord")
	private String vendorPassword;
public String getVendorName() {
	return vendorName;
}
public void setVendorName(String vendorName) {
	this.vendorName = vendorName;
}
public String getVendorPassword() {
	return vendorPassword;
}
public void setVendorPassword(String vendorPassword) {
	this.vendorPassword = vendorPassword;
}

}
