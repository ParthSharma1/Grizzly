package com.cognizant.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="VendorProducts")
public class VendorProducts {
	@Id
	@Column(name="Sr No")
	private int srNo;
	
	@OneToOne(cascade=CascadeType.ALL,targetEntity=Product.class)
	private Product product;
	
	private String ProductName;
	
	private String Brand;
	
	private int Buffer;
	
	@OneToOne(cascade=CascadeType.ALL,targetEntity=Vendor.class)
	private Vendor vendor;
	
	@Column(name="vendorId")
	private String vendorId;
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getQuantity() {
		return Quantity;
	}
	public void setQuantity(String quantity) {
		Quantity = quantity;
	}


	@Column(name="ProductId")
	private String productId;
	@Column(name="Quantity")
	private String Quantity;
	public int getSrNo() {
		return srNo;
	}
	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public String getProductName() {
		return ProductName;
	}
	public void setProductName(String productName) {
		ProductName = productName;
	}
	public String getBrand() {
		return Brand;
	}
	public void setBrand(String brand) {
		Brand = brand;
	}
	public int getBuffer() {
		return Buffer;
	}
	public void setBuffer(int buffer) {
		Buffer = buffer;
	}
	public Vendor getVendor() {
		return vendor;
	}
	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	
	
	@Override
	public String toString() {
		return "VendorProducts [srNo=" + srNo + ", product=" + product + ", ProductName=" + ProductName + ", Brand="
				+ Brand + ", Buffer=" + Buffer + ", vendor=" + vendor + "]";
	}
	
	
	
	
	
}
