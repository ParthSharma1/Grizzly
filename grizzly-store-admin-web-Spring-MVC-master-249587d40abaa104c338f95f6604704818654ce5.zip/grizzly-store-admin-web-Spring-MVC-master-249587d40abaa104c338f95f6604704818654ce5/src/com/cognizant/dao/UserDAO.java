package com.cognizant.dao;

public interface UserDAO {
	
	boolean checkUser(String User,String Pass);

}
