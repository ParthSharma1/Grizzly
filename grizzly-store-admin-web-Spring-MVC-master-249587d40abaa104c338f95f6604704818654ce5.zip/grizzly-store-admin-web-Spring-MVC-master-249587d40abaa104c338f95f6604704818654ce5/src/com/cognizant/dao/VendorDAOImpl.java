package com.cognizant.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Product;
import com.cognizant.entity.Vendor;
@Repository
public class VendorDAOImpl implements VendorDAO {
	
	
	
	@Autowired
	private SessionFactory sessionfactory;
	@Override
	public Vendor checkVendor(String user, String pass) {
		
		System.out.println(user+"   "+pass);
		
		Session session=sessionfactory.openSession();
		Transaction tx=session.beginTransaction();
		Query query = session.createQuery("from Vendor v where v.vendorName=:User and v.vendorPassword=:Pass");
		query.setParameter("User", user);
		query.setParameter("Pass",pass);
		List<Vendor> vendorList=query.list();
		Vendor vendor= new Vendor();
		for(Vendor v1: vendorList){
			vendor=v1;
		}
		tx.commit();
		sessionfactory.close();
		return vendor;
	}
	@Override
	public List<Product> getAllproduct(String VendorId) {
			// TODO Auto-generated method stub
			Session session=sessionfactory.openSession();
			List<Product> productList=session.createQuery("from Product").list();
			session.close();
			return productList;
		}
	

}


