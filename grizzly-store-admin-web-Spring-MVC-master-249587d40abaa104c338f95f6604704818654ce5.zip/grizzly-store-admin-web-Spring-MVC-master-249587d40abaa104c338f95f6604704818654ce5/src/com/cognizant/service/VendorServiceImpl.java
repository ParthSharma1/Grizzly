package com.cognizant.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.VendorDAO;
import com.cognizant.entity.Product;
import com.cognizant.entity.Vendor;
@Service
public class VendorServiceImpl implements VendorService {
	
	@Autowired
	private VendorDAO vendordao;
	
	@Override
	public Vendor checkVendor(String User, String Pass) {
		
		return vendordao.checkVendor(User,Pass);
	}

	@Override
	public List<Product> getAllproduct(String VendorId) {
		// TODO Auto-generated method stub
		return vendordao.getAllproduct(VendorId);
	}

}
