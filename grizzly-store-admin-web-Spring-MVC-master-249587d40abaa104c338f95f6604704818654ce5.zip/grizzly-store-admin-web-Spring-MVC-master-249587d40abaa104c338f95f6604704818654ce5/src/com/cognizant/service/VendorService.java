package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Product;
import com.cognizant.entity.Vendor;

public interface VendorService {
	Vendor checkVendor(String User,String pass);
	List<Product> getAllproduct(String vendorId);
	
	
}
