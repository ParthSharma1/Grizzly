package com.cognizant.service;

public interface UserService {
	
	boolean checkUser(String User,String Pass);

}
