package com.cognizant.service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.*;
import com.cognizant.entity.Admin;
@Service
public class AdminServiceImpl implements AdminService {

	@Autowired 
	private AdminDAO adminDAO;
	
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	public int validateAdmin(Admin admin) {
		// TODO Auto-generated method stub
		logger.info("-----------CHECCKING ADMIN SERVICE-----------------");
		return adminDAO.getAdminDetails(admin);
		
	}
	public boolean registerAdmin(Admin admin) {
		logger.info("-----------REGISTER ADMIN SERVICE-----------------");
		return adminDAO.registerAdmin(admin);
	}
	public int checkAdminCredentials(Admin admin) {
		// TODO Auto-generated method stub
		logger.info("-----------DOLOGIN ADMIN SERVICE-----------------");
		return adminDAO.checkAdmin(admin);
	}

}
