package com.cognizant.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDAOImpl;
import com.cognizant.dao.BranchAdminDAO;
import com.cognizant.entity.BranchAdmin;


@Service
public class BranchAdminServiceImpl implements BranchAdminService{

	@Autowired
	private BranchAdminDAO branchAdminDAO;
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	public boolean insertBranchAdminDetails(BranchAdmin branchAdmin) {
		// TODO Auto-generated method stub
		 
		logger.info("----------INSERT BRANCHADMIN SERVICE---------------");
		return branchAdminDAO.insertBranchAdmin(branchAdmin);
	}

	public List<BranchAdmin> getBranchAdminDetails() {
		// TODO Auto-generated method stub
		
		logger.info("----------GET ALL BRANCHADMIN SERVICE---------------");
		return branchAdminDAO.getBranchAdmin();
	}

	public int checkBranchAdminDetails(BranchAdmin branchAdmin) {
		// TODO Auto-generated method stub
		logger.info("----------CHECK  BRANCHADMIN CONTACT AND EMAIL SERVICE---------------");
		return branchAdminDAO.checkBranchAdmin(branchAdmin);
	}

	public boolean updateBranchAdminDetails(BranchAdmin branchAdmin) {
		// TODO Auto-generated method stub
		
		logger.info("----------UPDATE BRANCHADMIN SERVICE---------------");
		return branchAdminDAO.updateBranchAdmin(branchAdmin);
	}

	public BranchAdmin getBranchAdminInfo(String branchAdminId) {
		// TODO Auto-generated method stub
		logger.info("----------GET BRANCHADMIN OBJECT SERVICE---------------");
		return branchAdminDAO.fetchBranchAdminInfo(branchAdminId);
	}

}
