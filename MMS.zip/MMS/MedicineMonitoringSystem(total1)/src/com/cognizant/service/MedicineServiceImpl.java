package com.cognizant.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDAOImpl;
import com.cognizant.dao.MedicineDAO;
import com.cognizant.entity.Medicine;
@Service
public class MedicineServiceImpl implements MedicineService{
	
	@Autowired
	private MedicineDAO medicineDAO;
	
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	
	public List<Medicine> getAllMedicines() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING ALL MEDICINE SERVICE---------------");
		return medicineDAO.getAllMedicines();
	}

	
	public int addMedicine(Medicine medicine) {
		
		logger.info("----------REGISTER  MEDICINE SERVICE---------------");
		
		if(medicine.getPrescribedFor().equals("A")||medicine.getPrescribedFor().equals("C"))
			{
			logger.info("----------PRESCRIBED FOR A OR C MEDICINE SERVICE---------------");
			
			return medicineDAO.addMedicine(medicine);}
		else 
			return 1;
	
	}

	
	public boolean updateMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		
		logger.info("----------UPDATE MEDICINE SERVICE---------------");
		return medicineDAO.updateMedicine(medicine);
		
	}

	
	public Medicine retrieveMedicine(String medicineId) {
		
		logger.info("----------GETTING MEDICINE OBJECT SERVICE---------------");
		int medId=Integer.parseInt(medicineId);
		return medicineDAO.retrieveMedicine(medId);
		
	}

	
	public List<Medicine> getStockList() {
		// TODO Auto-generated method stub
		
		logger.info("----------GETTING STOCKLIST IN MEDICINE SERVICE---------------");
		return medicineDAO.getStockList();
	}


	public boolean updateMedicineQuantity(Medicine medicine) {
		// TODO Auto-generated method stub
		logger.info("----------UPDATE QUANTITY OF MEDICINE IN  MEDICINE SERVICE---------------");
		return medicineDAO.updateMedicineQuantity(medicine);
	}



	
}
