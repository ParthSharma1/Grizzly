package com.cognizant.service;

import java.util.Hashtable;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dao.AdminDAOImpl;
import com.cognizant.dao.MedicineRequestDAO;
import com.cognizant.entity.MedicineRequest;

@Service("MedicineRequestServiceImpl")
public class MedicineRequestServiceImpl implements MedicineRequestService{

	@Autowired
	private MedicineRequestDAO medicineRequestDAO;
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	public boolean insertMedicineRequest(MedicineRequest medicineRequest) {
		// TODO Auto-generated method stub
		
		logger.info("----------INSERT MEDICINE SERVICE---------------");
		return medicineRequestDAO.insertMedicineRequest(medicineRequest);
	}

	public List<MedicineRequest> getMedicineRequests() {
		// TODO Auto-generated method stub
		
		logger.info("----------GET ALL MEDICINES SERVICE---------------");
		return medicineRequestDAO.getMedicineRequests();
	}

	public boolean checkMedicineRequest(MedicineRequest medicineRequest) {
		// TODO Auto-generated method stub
		logger.info("----------CHECK MEDICINE QUNTITY  SERVICE---------------");
		Hashtable<Integer,Integer> hm=new Hashtable<Integer,Integer>();
		hm.put(medicineRequest.getMedicine1Id(), medicineRequest.getQuantity1());
		hm.put(medicineRequest.getMedicine2Id(), medicineRequest.getQuantity2());
		hm.put(medicineRequest.getMedicine3Id(), medicineRequest.getQuantity3());
		hm.put(medicineRequest.getMedicine4Id(), medicineRequest.getQuantity4());
		hm.put(medicineRequest.getMedicine5Id(), medicineRequest.getQuantity5());
		return medicineRequestDAO.checkMedicineRequest(hm);
	}

	public boolean updateBranchAdminRequest(MedicineRequest medicineRequest) {
		// TODO Auto-generated method stub
		logger.info("----------UPDATE MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.updateBranchAdminRequest(medicineRequest);
	}

	public MedicineRequest fetchMedicineRequestInfo(int requestId) {
		// TODO Auto-generated method stub
		logger.info("----------GET MEDICINEREQUEST OBJECT SERVICE---------------");
		return medicineRequestDAO.fetchMedicineRequestInfo(requestId);
	}

	public List<String> getBranchAdminIds() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING BRANCH ADMIN LIST IN MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.getBranchAdminIds();
	}

	public List<Integer> getMedicineIds() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING MEDICINES ID IN  MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.getMedicineIds();
	}

	public int getRequestPendingCount() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING  REQUEST PENDING COUNT IN MEDICINEREQUEST SERVICE---------------");
		return medicineRequestDAO.getRequestPendingCount();
	}



	

}
