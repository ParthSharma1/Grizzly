package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.BranchAdmin;

public interface BranchAdminService {

	boolean insertBranchAdminDetails(BranchAdmin branchAdmin);
    List<BranchAdmin> getBranchAdminDetails();
    int checkBranchAdminDetails(BranchAdmin branchAdmin);
    boolean updateBranchAdminDetails(BranchAdmin branchAdmin);
    BranchAdmin getBranchAdminInfo(String branchAdminId);
}
