package com.cognizant.service;

import com.cognizant.entity.Admin;

public interface AdminService {

	int validateAdmin(Admin admin);
	boolean registerAdmin(Admin admin);
	int checkAdminCredentials(Admin admin);
}
