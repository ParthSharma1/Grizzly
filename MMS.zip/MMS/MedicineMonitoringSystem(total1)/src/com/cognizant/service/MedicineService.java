package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.Medicine;

public interface MedicineService {
	List<Medicine> getAllMedicines();
	int addMedicine(Medicine medicine);
	boolean updateMedicine(Medicine medicine);
	Medicine retrieveMedicine(String medicineId);
	List<Medicine> getStockList();
	boolean updateMedicineQuantity(Medicine medicine);
	
	
}
