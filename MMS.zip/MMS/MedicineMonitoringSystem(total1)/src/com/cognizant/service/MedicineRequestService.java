package com.cognizant.service;

import java.util.List;

import com.cognizant.entity.MedicineRequest;

public interface MedicineRequestService {
	boolean insertMedicineRequest(MedicineRequest medicineRequest);
    List<MedicineRequest> getMedicineRequests();
    boolean checkMedicineRequest(MedicineRequest medicineRequest);
    boolean updateBranchAdminRequest(MedicineRequest medicineRequest);
    MedicineRequest fetchMedicineRequestInfo(int requestId);
    List<String> getBranchAdminIds();
    List<Integer> getMedicineIds();
    int getRequestPendingCount();
	

}
