package com.cognizant.validation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.cognizant.entity.Admin;
import com.cognizant.entity.Medicine;
import com.cognizant.service.MedicineService;
@Component("AddMedicineValidator")
public class AddMedicineValidator implements Validator {
	@Autowired
	private MedicineService medicineService;
	
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return arg0.equals(Medicine.class);
	}

	public void validate(Object arg0, Errors arg1) {
		// TODO Auto-generated method stub
		Medicine medicine=(Medicine)arg0;
		int result=medicineService.addMedicine(medicine);
		
		if(result==1)
		{
			arg1.rejectValue("prescribedFor","com.cognizant.controller.prescribedFor");
		}
		
		
	}

}
