package com.cognizant.exception;

public class ResponseException extends RuntimeException {

	public ResponseException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
