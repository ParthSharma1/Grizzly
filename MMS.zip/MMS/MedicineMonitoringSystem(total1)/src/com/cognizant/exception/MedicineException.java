package com.cognizant.exception;

public class MedicineException extends RuntimeException {

	public MedicineException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
