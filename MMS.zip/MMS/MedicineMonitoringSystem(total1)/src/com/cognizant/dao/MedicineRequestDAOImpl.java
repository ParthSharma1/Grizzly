package com.cognizant.dao;

import java.math.BigDecimal;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.BranchAdmin;
import com.cognizant.entity.Medicine;
import com.cognizant.entity.MedicineRequest;

import oracle.net.aso.q;

@Repository
public class MedicineRequestDAOImpl implements MedicineRequestDAO{
	@Autowired
	private SessionFactory sessionFactory;
	
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	
	public boolean insertMedicineRequest(MedicineRequest medicineRequest) {
		// TODO Auto-generated method stub
		
		logger.info("----------INSERT MEDICINE REQUEST IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
		generateMedicineRequestId();
		Transaction tx = session.beginTransaction();
		session.persist(medicineRequest);
		tx.commit();
		session.close();
		return true;
	}

	public List<MedicineRequest> getMedicineRequests() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING ALL REQUEST IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from MedicineRequest o where o.adminResponse='P'");
		List<MedicineRequest> medicineRequestList=query.list();
		return medicineRequestList;
	}

	public boolean checkMedicineRequest(Hashtable<Integer,Integer> hm) {
		boolean quantityCheck=true;
		logger.info("----------CHECKING MEDICINE REQUEST IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
		  for(Map.Entry map:hm.entrySet()){  
			   
			   Query query=session.createQuery("from Medicine o where o.medicineId=:medicineId");
			   query.setInteger("medicineId",(Integer) map.getKey());
			   List<Medicine> medicineList=query.list();
			   for(Medicine medicine:medicineList){
				   if(medicine.getQuantity()<Integer.parseInt(""+map.getValue())){
					   quantityCheck=false;
					   return quantityCheck; 
				   }
			   }
			 
			  }
		return quantityCheck; 
			
		
	}

	public boolean updateBranchAdminRequest(MedicineRequest medicineRequest) {
		// TODO Auto-generated method stub
		logger.info("----------UPDATE MEDICINE REQUEST IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
		Transaction tx = session.beginTransaction();
		session.merge(medicineRequest);
		tx.commit();
		session.close();
		return true;
	}

	public MedicineRequest fetchMedicineRequestInfo(int requestId) {
		// TODO Auto-generated method stub
		logger.info("----------GETTING MEDICINE REQUEST ID IN MEDICINEREQUESTDAO---------------");
		Session session = sessionFactory.openSession();
		MedicineRequest medicineRequest=(MedicineRequest) session.load(MedicineRequest.class, requestId);
		return medicineRequest;
	}
	
	public void generateMedicineRequestId(){
		
		logger.info("----------GETTING MEDICINE REQUEST ID IN MEDICINEREQUESTDAO---------------");
		 Session session=sessionFactory.openSession();
		 Query query = session.createSQLQuery("select MedicineRequestId.nextval FROM DUAL" );
		 Long key = ((BigDecimal) query.uniqueResult()).longValue();
		 StoreMedicineRequestId.addMedicineRequestId(key.intValue());
	 
	}

	public List<String> getBranchAdminIds() {
		// TODO Auto-generated method stub
		
		logger.info("----------GETTING BRANCHADMINS IDS LIST IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("Select o.branchAdminId from BranchAdmin o");
		List<String> medicineIdList=query.list();
		return medicineIdList;
	
	}

	public List<Integer> getMedicineIds() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING MEDICINES IDS IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("Select o.medicineId from Medicine o");
		List<Integer> medicineIdList=query.list();
		return medicineIdList;
	}

	public int getRequestPendingCount() {
		// TODO Auto-generated method stub
		logger.info("----------GETTING PENDING MEDICINE MEDICINE REQUEST IN MEDICINEREQUESTDAO---------------");
		Session session=sessionFactory.openSession();
        Query query=session.createSQLQuery("select PENDING from REQUESTRESPONSETRIGGERTABLE where SRNO=1");
        BigDecimal count=(BigDecimal)query.uniqueResult();
        System.out.println(count.intValue());
		return count.intValue();
	}

	
	

	

}
