package com.cognizant.dao;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.Medicine;
@Repository
public class MedicineDAOImpl implements MedicineDAO {
	
	@Autowired
	SessionFactory sessionFactory;
	
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	
	public List<Medicine> getAllMedicines() {
		
		logger.info("-----------GETTING ALL MEDICINE DAO-----------------");
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Medicine");
		List<Medicine> medList=query.list();
		sessionFactory.close();
		return medList;
	}

	public int addMedicine(Medicine medicine) {
		logger.info("-----------REGISTER MEDICINE DAO-----------------");
		
		Session session=sessionFactory.openSession();
		generateMedicineId();
		Transaction tx=session.beginTransaction();
		
		session.persist(medicine);
		
		tx.commit();
		session.close();
		return 0;
	}
	

	public boolean updateMedicine(Medicine medicine) {
		// TODO Auto-generated method stub
		
		logger.info("-----------UPDATE MEDICINE DAO-----------------");
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		session.merge(medicine);
		boolean res=true;
		tx.commit();
		session.close();
		return res;
		
	}

	public Medicine retrieveMedicine(int medicineId) {
		// TODO Auto-generated method stub
		logger.info("-----------RETRIEVE MEDICINE OBJECT DAO-----------------");
		Session session=sessionFactory.openSession();
		Medicine medicine=(Medicine) session.load(Medicine.class, medicineId);
		return medicine;
		
		
	}


	public List<Medicine> getStockList() {
		// TODO Auto-generated method stub
		logger.info("-----------GETTING MEDICINE STOCK LIST DAO-----------------");
		Session session=sessionFactory.openSession();
		Query query=session.createQuery("from Medicine");
		List<Medicine> stockList=query.list();
		sessionFactory.close();
		return stockList;
			}


	public boolean updateMedicineQuantity(Medicine medicine) {
		logger.info("-----------UPDATE MEDICINE QUANTITY DAO-----------------");
		Session session=sessionFactory.openSession();
		Transaction tx=session.beginTransaction();
		//Query query=session.createQuery("SELECT m.quantity FROM medicine m");
		
		session.merge(medicine);
	/*	Query query=session.createQuery("Update Medicine m set m.quantity = :quantity where m.medicineId= :medicineId");
		query.setParameter("quantity", medicine.getQuantity()); 
		query.setParameter("medicineId", medicine.getMedicineId());*/
		
		boolean res=true;
		tx.commit();
		session.close();
		return res;
	}
	public void generateMedicineId(){
		logger.info("-----------GENRATE MEDICINE ID DAO-----------------");
		
		 Session session=sessionFactory.openSession();
		 Query query = session.createSQLQuery("select MEDICINESEQ.nextval FROM DUAL" );
		 Long key = ((BigDecimal) query.uniqueResult()).longValue();
		 StoreMedicineId.addMedicineId(key.intValue());

	}

	

}
