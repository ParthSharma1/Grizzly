package com.cognizant.dao;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.SessionImplementor;
import org.hibernate.id.enhanced.SequenceStyleGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MedicineRequestIdGenerator extends SequenceStyleGenerator{
	
	private static Logger logger=LoggerFactory.getLogger(AdminDAOImpl.class);
	public Serializable generate(SessionImplementor arg0, Object arg1)
			throws HibernateException {
	  
		logger.info("----------MEDICINE REQUEST ID GENERATOR---------------");
	     return StoreMedicineRequestId.getMedicineRequestId();
}
}